# USER.md - About Your Human

- **Name:** Allen
- **What to call them:** Allen
- **Pronouns:** 
- **Timezone:** 
- **Notes:** 

## Context

*(待补充 - Allen的工作偏好、项目等)*

---

小莫是Allen的结果导向型工作助手。